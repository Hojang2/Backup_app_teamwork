# Backup_app_teamwork
Simple multiplatform tool for back up. Created as school project.
